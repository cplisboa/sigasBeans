package sigas;

public class StatusPoco {

	public Poco poco;
	public Medida med;
	public boolean isOperating=false;
	public boolean unknownState=false;
	long difDias = 0;

	public StatusPoco(Poco poco, Medida med) {
		super();
		this.poco = poco;
		this.med = med;
	}
	
	/** Calcula mensagem de warning que deve ser mostrada para determinado po�o */
	public String getFrase() {
		String frase="";
		if(med==null) {
			frase = "NENHUMA MEDIDA ENCONTRADA PARA ESSE PO&Ccedil;O";
		} else {
			// Existem medidas

			//Verifica se temos problemas no tempo sem leitura do po�o
			java.sql.Timestamp sqlTs = med.getTs();
			java.util.Date ts = (java.util.Date) sqlTs;
		
			java.sql.Timestamp now = new java.sql.Timestamp(System.currentTimeMillis());		
			long diff = now.getTime() - ts.getTime();     
    
			long difHoras = diff/1000/60/60;
			long difDias = diff/1000/60/60/24;
				
			if(difDias >= 1) {
				frase = "Sem leitura a "+difDias+" dia(s)";
				unknownState = true;
			} else if (difHoras  > 8) {
				frase = "Sem leitura a "+difHoras+" horas";			
				unknownState = true;
			} else {
				// Po�o tem medidas e s�o recentes, verificando opera��o.
				if(med.getCorrente() > 0) {
					frase = "Em opera&ccedil;&atilde;o";
				} else {
					frase = "Em repouso";
				}								
			}
		}
		return frase;
				
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
