package sigas;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
//import java.sql.SQLException;
import java.util.StringTokenizer;



public class DataRequester {

    private Database db=null;
    private String urlDb = null;

	public DataRequester(String url) {
		urlDb = url;
	}

	public Database getDb() {
		return db;
	}
	
	/** Retorna array com todos os po�os de um sistema com seus respectivos dados cadastrais e ultimas medidas */
	public StatusPoco[] pocosOnline(int idSistema){
		
		Sistema sys = new Sistema(idSistema);
		StatusPoco[] statusPoco = null;
		Database db = new Database();
		sys.fillPocos(db);
		Poco[] pocos = sys.getPocos();
		statusPoco = new StatusPoco[pocos.length];		
		
		//Percorre lista de po�os do sistema para recuperar dado online
		for (int i=0; i<pocos.length; i++) { 
		    System.out.println("Po�o: " + pocos[i].getName());				
		    Medida med = onlineData(pocos[i].getCode());
		    statusPoco[i] = new StatusPoco(pocos[i], med);
		    
		    
			if (med!=null) { 
				// Verificando se o po�o est� em opera��o
				if(med.getCorrente() > 0) {
					statusPoco[i].isOperating = true;
				}
				//Recupera informa��o de h� quanto tempo n�o temos medidas do po�o
				java.sql.Timestamp sqlTs = med.getTs();
				java.util.Date ts = (java.util.Date) sqlTs;
			
				Timestamp now = new Timestamp(System.currentTimeMillis());		
				long diff = now.getTime() - ts.getTime();     
		
				long difHoras = diff/1000/60/60;
				long difDias = diff/1000/60/60/24;
				
				statusPoco[i].difDias = difDias;
				if(difDias >= 1) {
					statusPoco[i].unknownState = true;
				} else if (difHoras  > 8) {
					statusPoco[i].unknownState = true;
				}
			}
		}
		db.close();
		return statusPoco;
		
		
	}	
	

	
	/**
	 * Consulta a base e retorna ultima medida inserida
	 * 
	 */
	public Medida onlineData(String code){
		Medida med = null;
		String consulta = "SELECT FIRST 1 * FROM SIGAS_POCOS WHERE CODIGO_STR = '" + code + "' ORDER BY DATA DESC";
		
		ResultSet rs = null;
        System.out.println("Iniciando conex�o com banco de dados");
    	db = new Database(urlDb,"SYSDBA","masterkey");
    	try{
    		//Recuperando ultimo dado do bd
        	rs=db.execQuery(consulta);
        	if(rs.next()){        		
        		med = createMedida(rs, "nivel");
        	} else {
        		System.out.println("Nenhum dado na base?");
        	}      
        	rs.close();
    	} catch(Exception e) {
    		System.out.println("Erro recuperando ultimo dado inserido");
    	}
    	db.close();
    	return med;
	}
		
	
	/** Recupera as medidas PR�XIMAS aquele dia (-10 at� +10)
	 * 
	 * @param dayStr
	 * @param code
	 * @param type Tipo do dado a ser recuperado (nivel, vazao, corrente)
	 * @return
	 */
	public Medida[][] daysData(String dayStr, String code, String type) {
		Medida[][] med = new Medida[20][24];
		int linhas = 20;
						
		//Setar a data requisitada em um calendar
	    java.util.Calendar cal = Calendar.getInstance();			
	  	StringTokenizer strData = new StringTokenizer(dayStr, "/");	
		int dia = Integer.parseInt(strData.nextToken());
		int mes = Integer.parseInt(strData.nextToken())-1;
		int ano = Integer.parseInt(strData.nextToken());
	    cal.set(ano,mes,dia);

	    //Diminui 10 para pegar 10 dias antes e 10 dias depois
	    cal.add(Calendar.DATE, -10);
	    
		System.out.println("Iniciando conex�o com banco de dados");
		db = new Database(urlDb,"SYSDBA","masterkey");
		
	    for(int i=0; i<linhas; i++) {
	    	//Pegando proximo dia
	    	cal.add(Calendar.DATE, 1);
		    
		    String day = "" +(cal.get(Calendar.DAY_OF_MONTH));
		    if (day.length() == 1)
		    	day = "0"+day;
		    
		    String mesPrint = "" +(cal.get(Calendar.MONTH)+1);
		    if (mesPrint.length() == 1)
		        mesPrint = "0"+mesPrint;
		    
		    String diaPrint = cal.get(Calendar.YEAR) + "/" + mesPrint + "/" + day;
		    
		    String consulta = "";
		    if (type.equals("nivel")) { 
		    	consulta = "SELECT * FROM sigas_pocos where codigo_str = '" + code + "' and data BETWEEN '" + diaPrint+" 00:00:00' and '" + diaPrint +" 23:59:59' order by data";
		    } else if ((type.equals("vazao")) || (type.equals("corrente")) || (type.equals("cesp"))) {
    	        consulta = "select * from grandezas where code = '" + code + "' and data BETWEEN '" + diaPrint+" 00:00:00' and '" + diaPrint +" 23:59:59' order by data";		    	
		    }
 			
 			//System.out.println(consulta);
			ResultSet rs = null;			  
			  
			try {				    
				//Recuperando ultimo dado do bd
			    rs=db.execQuery(consulta);
			        
				while (rs.next()){				
					Timestamp ts = rs.getTimestamp("DATA");
					// Recupera hora do RS para usar na "linha"
					int hora = ts.getHours();
					med[i][hora] = createMedida(rs, type);		    
				 }
				 rs.close();				
		    } catch (Exception e) {
			    System.out.println("Erro fazendo consulta diaria e criando medida "+e.getMessage());
		    }
	    } 	
	    db.close();
	    return med;
	}
		
	
	private Medida createMedida(ResultSet rs, String type) {
		Medida med = null;
		float nivel = 0;
		try {
			if(type.equals("nivel"))
				nivel = rs.getFloat("nivel");
			float corrente = rs.getFloat("corrente");
			float vazao = rs.getFloat("vazao");
			int volume = rs.getInt("volume");
			Timestamp ts = rs.getTimestamp("data");
			float cesp = rs.getFloat("cesp");
			med = new Medida(nivel, corrente, vazao, volume, cesp, ts);
		} catch (Exception e) {
			System.out.println("Erro lendo rs em create medida");
		}
		return med;		
	}
	
	private void createLines (Database db, int pocoId) throws Exception {
		String sql = "insert into operacionais (idpoco) values ("+ pocoId +")";
		String sql2 = "insert into poco_hidrogeo (poco_no) values ("+ pocoId +")";
		//String sql3 = "insert into poco_hidrogeo (idpoco) values ("+ pocoId +")";
		System.out.println(sql);
		db.insert(sql);
		db.insert(sql2);
		
	}
	
	private int getPocoId(Database db) {
		int gen = 0;
		try {
			ResultSet rs = db.execQuery("select gen_id(POCO_ID, 1) from rdb$database");
			rs.next();
			gen = Integer.parseInt(rs.getString("GEN_ID"));
			rs.close();
		} catch (Exception e) {
			System.out.println("Erro recuperando Id do poco para criar "+e.getMessage());
		}
		return gen;
	}
	
	/**
	 * M�todo criado para termos um cadastro simplificado de po�o
	 * 
	 * @param nome Nome ou n�mero do po�o
	 * @param id_sistema Id do Sistema
	 * @param superin Superintend�ncia
	 * @param utm_norte UTM Norte (coordenada usada como identificador do po�o ao receber dados)
	 */
	public boolean createPocoSlim (String nome, int id_sistema, String superin, String utm_norte, String utm_leste) {
		boolean result = true;
		db = new Database(urlDb,"SYSDBA","masterkey");
		
		//Recupera proximo Id do generator que ser� usado
		int generator = getPocoId(db);
		String sql = "insert into poco_gerais (nome, id_sistema, utm_norte, utm_sul, id_poco) values ("
				+ "'" + nome + "',"
				+ id_sistema +","
				+ "'" + utm_norte + "',"
				+ "'" + utm_leste + "',"
				+ generator + ")";
		
		System.out.println(sql);
		try {
			db.insert(sql);
			//Cria tamb�m entrada nas tabelas operacionais, hidrogeologicas, etc.
			createLines(db, generator);
		} catch(Exception e) {
			System.out.println("Erro criando Poco Slim "+e.getMessage());
			result=false;
		}
		db.close();
		return result;				
	}
	
	public int createPoco (String nome, String endereco, String localidade, String municipio, String uf, String cep, String utm_norte, String utm_sul, String latitude, String longitude, String outorga_no, String art, String tecnico, String art_no, String finalidade, String vazao_outorgada, String volume_out, String situacao, String reativado_data, String obs, int id_sistema) {
		System.out.println("Entrei em createPoco. Vou conectar....");
		db = new Database(urlDb,"SYSDBA","masterkey");		
		String query = "insert into poco_gerais values ('" 
				+ nome + "', '" 
				+ endereco + "', '" 
				+ localidade + "', '" 
				+ municipio + "', '" 
				+ uf + "', '" 
				+ cep + "', '" 
				+ utm_norte + "', '" 
				+ utm_sul + "', '" 
				+ latitude + "', '" 
				+ longitude + "', '" 
				+ outorga_no + "', '" 
				+ art + "', '" 
				+ tecnico + "', '" 
				+ art_no + "', '" 
				+ finalidade + "', '" 
				+ vazao_outorgada + "', '" 
				+ volume_out + "', '" 
				+ situacao + "', '" 
				+ reativado_data + "', '" 
				+ obs + "', "
				+ "GEN_ID(POCO_ID, 1)" + ", "
				+ id_sistema + ")";
		System.out.println(query);
		try {
			db.insert(query);	
		} catch(Exception e) {
			System.out.println("Erro criando Poco "+e.getMessage());
		}
		db.close();
			
		return 1;
	}

	/** Recupera lista de pocos por sistema
	 * 
	 * @param sistema
	 * @return
	 * @throws SQLException 
	 */
	/*
	public Poco[] getPocos(int id_sistema) {
		ArrayList<Poco> pocosList = new ArrayList<Poco>();
		
		System.out.println("Iniciando conex�o com banco de dados");
		db = new Database(urlDb,"SYSDBA","masterkey");

		try {
			ResultSet rs = db.execQuery("select nome, utm_norte from poco_gerais where id_sistema="+id_sistema);
			while (rs.next()){				
				String nome = rs.getString("nome");
				String code = rs.getString("utm_norte");
				System.out.println("Recuperei um poco de nome: "+nome+" e c�digo: "+code);
				pocosList.add(new Poco(nome, code));
			}
		} catch (Exception e) {
			System.out.println("Erro recuperando lista de pocos. "+e.getMessage());
		}
		db.close();
		Poco[] pocosArray = new Poco[pocosList.size()];
		pocosList.toArray(pocosArray);
		return pocosArray;
		
	}
	*/
	
	public Empresa[] getEmpresas() {
		String busca = "select * from empresa";
		ArrayList<Empresa> list = new ArrayList<Empresa>(5);
				
		ResultSet rs = null;
		
    	Database db = new Database();
    	try{
        	rs = db.execQuery(busca);
        	while (rs.next()) {
        		int id = rs.getInt("empresa_id");
        		String empresa = rs.getString("empresa");
        		String contrato = rs.getString("contrato");
        		int num_sistema = rs.getInt("num_sistema"); 
        		String modulos = rs.getString("modulos");
        		int num_pocos = rs.getInt("num_pocos");
        		int num_usuarios = rs.getInt("num_usuarios");
        		String numContrato = rs.getString("numContrato");
        		
        		//Recuperando usuario master
        		String masterUser = getMaster(id);
        		Empresa emp = new Empresa(id, empresa, contrato, num_sistema, modulos, num_pocos, num_usuarios, masterUser, numContrato);

        		list.add(emp);
        	}
        	rs.close();
    	} catch(Exception e) {
    		System.out.println("Erro recuperando lista de empresas. "+e.getMessage());
    		e.printStackTrace();
    	} finally {
    		db.close();    		
    	}
    	Empresa[] empArray = new Empresa[list.size()];
    	return list.toArray(empArray);
	}	
	
	/** Recuperando usu�rio master */
	private String getMaster(int id_empresa){
		String busca = "select usuario from usuario where id_empresa = " + id_empresa + " and acesso='diretor'";
		String masterUser = "N�O EXISTENTE";
		
    	Database db = new Database();
    	ResultSet rs = null;
		
    	try{
        	rs = db.execQuery(busca);
        	if (rs.next()) {
        		masterUser= rs.getString("usuario");
        	} else {
        		System.out.println("N�o existe usu�rio diretor para a empresa de id = "+id_empresa);
        	}
    		rs.close();
    	} catch(Exception e) {
    		System.out.println("Erro recuperando usuario master da empresa de id = " + id_empresa + " > "+e.getMessage());
    	} finally {

    		db.close();    		
    	}
    	return masterUser;
	}
	
	/**
	 * Recupera lista de sistemas a partir do ID da EMPRESA
	 * @param id_empresa
	 * @return
	 */
	public Sistema[] getSistemas (int id_empresa) {
		ArrayList<Sistema> sistemasList = new ArrayList<Sistema>();
		
		System.out.println("Iniciando conex�o com banco de dados");
		db = new Database(urlDb,"SYSDBA","masterkey");

		try {
			ResultSet rs = db.execQuery("select * from sistema where empresa_id='"+id_empresa+"' order by nome");
			while (rs.next()){				
				int sistema_id = rs.getInt("sistema_id");
				String nome = rs.getString("nome");
				System.out.println("Recuperei um Sistema de nome: "+nome+" e id: "+sistema_id);
				sistemasList.add(new Sistema(sistema_id, id_empresa, nome));
			}
		} catch (Exception e) {
			System.out.println("Erro recuperando lista de Sistemas. "+e.getMessage());
		}
		db.close();
		Sistema[] sistArray = new Sistema[sistemasList.size()];
		sistemasList.toArray(sistArray);
		return sistArray;		
		
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DataRequester dr = new DataRequester("jdbc:firebirdsql:localhost/3050:C:/juper/old_site/SIGAS.GDB");
		
		//DataRequester dr = new DataRequester("jdbc:firebirdsql:localhost/3050:C:/juper/old_site/SIGAS.GDB");
/*		
		Medida med = (Medida) dr.onlineData("450814E");
		float fl = med.getVazao();
		System.out.println("Vazao eh: "+fl);
		System.out.println("Volume eh: "+med.getVolume());
		
		Sistema[] list = dr.getSistemas(11);
		for (int i=0; i<list.length; i++)
			System.out.println(list[i].getId_sistema()+" - "+list[i].getNome());
*/
		
		
		/*
		Empresa[] emp = dr.getEmpresas();
		
		for(int i=0; i<emp.length; i++) {
			System.out.println("Empresa: " + emp[i].getNome() );
			System.out.println("... Contrato: " + emp[i].getContrato());
			System.out.println("... Usuario master: " + emp[i].getMasterUser());
		}*/
		
		
		/*
		StatusPoco[] status = dr.pocosOnline(2);
		for(int i=0; i<status.length; i++) {
			System.out.println("-----  Po�o: "+status[i].poco.getName()+ " operacao: "+status[i].isOperating + " Status: "+status[i].unknownState);
		}*/
/*		
		Medida med = (Medida) dr.onlineData("489294.33e");
		java.sql.Timestamp sqlTs = med.getTs();
		java.util.Date ts = (java.util.Date) sqlTs;
		
		dr.createPocoSlim("Sexto", 7, "tri", "utmfsboa");
	*/	
		//Sistema[] list = dr.getSistemas(1);
		//dr.createPoco("teste", "end", "loc", "munic", "rs", "90230-220", "123456", "2312", "lat", "long", "out", "art", "tecnico", "art_no", "finali", "out", "e_ou", "sao", "data", "obs", 1);
		
		
		//dr.createPoco(32, "joaquim", "candongas10", "vila seca", "acordeao do oeste", "RS", "90002123", "utmnorte", "utm_sul", "121212", "long12", "2", "art2", "dunga", "2", "legal", "100", "10", "boa sim", "12/12/2012", "obs");
		
		//Medida med = dr.onlineData();

		// Empresa.updateEmpresa("Internacional","123456789","10","20","30","2", "master", "senha");		
		
	/*	
		Empresa emp = new Empresa(1);
		emp.setEmpresa(1);
		System.out.println("Nome da Empresa: "+emp.getNome());
		System.out.println("Num Sistemas: "+emp.getNum_sistemas());
		System.out.println("Num Pocos: "+emp.getNum_pocos());
		System.out.println("Num Usuarios: "+emp.getNum_usuarios());
		System.out.println("Num Modulos: "+emp.getNum_modulos());
		System.out.println("Num Contrato: "+emp.getNumContrato());
	*/
	/*	
		
		
		Empresa[] emp = dr.getEmpresas();
		
		for(int i=0; i<emp.length; i++) {
			System.out.println("Empresa: " + emp[i].getNome() );
			System.out.println("... Contrato: " + emp[i].getContrato());
			System.out.println("... Usuario master: " + emp[i].getMasterUser());
		}

		String modulos = emp[0].getModulos();
		StringTokenizer str = new StringTokenizer(modulos, ":");
		HashMap<String, String> hash = new HashMap<String, String>();
		
		while (str.hasMoreTokens()){			
			String unit = str.nextToken().trim();
			hash.put(unit, unit);			
		}
		
		
		if(hash.get("3")!= null)
			System.out.println("Tem 3 ");
		else
			System.out.println("N�o tem 3? ");
			
		if(hash.get("1")!= null)
			System.out.println("Tem 1 ");
		else
			System.out.println("N�o tem 1? ");
		
		if(hash.get("2")!= null)
			System.out.println("Tem 2 ");
		else
			System.out.println("N�o tem 2? ");
		
		
	*/	
		
		
		
		Medida med[][] = dr.daysData("18/11/2014","450814E","cesp");
		
		System.out.println("Dados recuperados...");
		for(int i=0; i<20; i++){
			for(int j=0; j<24; j++){
				if(med[i][j]!=null) {
					System.out.println("Medida na linha " + i + " hora: " + med[i][j].getTs().getHours());
					System.out.println("   Nivel: " + med[i][j].getNivel());
					System.out.println("   Corrente: " + med[i][j].getCorrente());
					System.out.println("   Vazao: " + med[i][j].getVazao());
					System.out.println("   Volume: " + med[i][j].getVolume());
					System.out.println("   CESP: " + med[i][j].getCesp());					
					System.out.println("   Time: "+med[i][j].getTs());
				}
			}
		}
		
		
		
		
		
		
	}

}
