package sigas;

public class MinhaPrimeira {

	public static void main(String[] args) {
		int a=3, b=5;
		

	}

}
